"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("rxjs-compat/add/observable/fromEventPattern");
//# sourceMappingURL=fromEventPattern.js.map