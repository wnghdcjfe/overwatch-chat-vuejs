"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("rxjs-compat/add/operator/toPromise");
//# sourceMappingURL=toPromise.js.map