"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AjaxObservable_1 = require("./AjaxObservable");
exports.ajax = AjaxObservable_1.AjaxObservable.create;
//# sourceMappingURL=ajax.js.map