import { MonoTypeOperatorFunction } from '../types';
export declare function refCount<T>(): MonoTypeOperatorFunction<T>;
