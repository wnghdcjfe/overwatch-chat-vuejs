import { OperatorFunction } from '../types';
export declare function isEmpty<T>(): OperatorFunction<T, boolean>;
